"""_summary_"""
from django.contrib import admin
from .models import (
    Categoria, Fornecedor, Cliente, Produto,
    Documento, ItemDocumento, MovimentacaoEstoque,
)

for modulo in (Categoria, Fornecedor, Cliente, Produto,
               Documento, ItemDocumento, MovimentacaoEstoque):
    admin.site.register(modulo)
